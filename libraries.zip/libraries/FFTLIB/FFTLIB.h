#ifndef FFTLIB_H
#define FFTLIB_H
#include <Arduino.h>
class FFTLIB
{
	public:
		FFTLIB(){}
		byte sine_data [91]=
		{
0,  
4,    9,    13,   18,   22,   27,   31,   35,   40,   44, 
49,   53,   57,   62,   66,   70,   75,   79,   83,   87, 
91,   96,   100,  104,  108,  112,  116,  120,  124,  127,  
131,  135,  139,  143,  146,  150,  153,  157,  160,  164,  
167,  171,  174,  177,  180,  183,  186,  189,  192,  195,       //Paste this at top of program
198,  201,  204,  206,  209,  211,  214,  216,  219,  221,  
223,  225,  227,  229,  231,  233,  235,  236,  238,  240,  
241,  243,  244,  245,  246,  247,  248,  249,  250,  251,  
252,  253,  253,  254,  254,  254,  255,  255,  255,  255
  };
		float f_peaks[5] = {0}; // top 5 frequencies peaks in descending order
		float FFT(int in[],int N,float Frequency);
		float sine(int i);
		float cosine(int i);
};
#endif